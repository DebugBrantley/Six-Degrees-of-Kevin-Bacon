cd RoboGrader
python3 robochecker.py Sixdegrees ~/workspace
cd ..
